Ksenia Erulevich, designer of the Alice typeface, was inspired by Lewis Carrol's novel and decided to make a typeface that will be suitable for typesetting that book.

It came out eclectic and quaint, old-fashioned, having widened proportions, open aperture, and soft rounded features; perfect for long meditative text-setting and headlines.

This is in fact Ksenia's first typeface, as part of her diploma project in a Type and Typography course in Moscow, Russia.

Released by Cyreal with help from Gayaneh Bagdasaryan and Alexei Vanyashin.